/**
 * Application Entry Point
 */

import { startServer } from './server.js';

startServer();
